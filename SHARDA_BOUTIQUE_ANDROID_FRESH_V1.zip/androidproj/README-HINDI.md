# SHARDA BOUTIQUE — Fresh Android App

यह fresh Android WebView app है। इसमें SHARDA BOUTIQUE का existing tailoring/customer app रखा गया है और नया professional logo app के अंदर तथा launcher icon में लगाया गया है।

मुख्य सुविधाएँ:
- Customer + mobile से existing customer खोलना
- एक customer में multiple garments/orders
- Kurti, Pant, Blouse measurements + Extra ordinary measurements
- Total, Advance, Balance
- Customer photo
- Garment photo: Gallery से एक साथ multiple photos चुन सकते हैं
- Camera और Gallery chooser
- Alteration section
- Delivery reminder
- WhatsApp / Message / Bill / Print
- Google Drive backup UI
- SHARDA BOUTIQUE professional logo

Build: Java 17 + Gradle 8.7 + Android Gradle Plugin 8.6.1
