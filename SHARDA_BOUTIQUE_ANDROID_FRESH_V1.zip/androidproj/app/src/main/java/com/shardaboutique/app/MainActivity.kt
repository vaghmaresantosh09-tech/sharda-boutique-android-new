package com.shardaboutique.app

import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.webkit.*
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import java.io.File

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val notificationReq = 20
    private val fileChooserReq = 101
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var cameraUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        WebView.setWebContentsDebuggingEnabled(false)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.settings.databaseEnabled = true
        web.settings.setSupportZoom(false)
        web.settings.mediaPlaybackRequiresUserGesture = false

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url.toString()
                if (u.startsWith("http://") || u.startsWith("https://")) {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)))
                    return true
                }
                return false
            }
        }

        // Android WebView file chooser with BOTH Camera and Files/Gallery.
        // Multiple image selection is enabled when the HTML input asks for it.
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                this@MainActivity.filePathCallback?.onReceiveValue(null)
                this@MainActivity.filePathCallback = filePathCallback
                cameraUri = null

                return try {
                    val acceptImages = fileChooserParams?.acceptTypes?.any {
                        it.isBlank() || it.startsWith("image/") || it == "*/*"
                    } == true

                    if (acceptImages) {
                        val cameraIntent = Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE)
                        val photoFile = File.createTempFile("sharda_camera_", ".jpg", cacheDir)
                        val outputUri = FileProvider.getUriForFile(
                            this@MainActivity,
                            "${packageName}.fileprovider",
                            photoFile
                        )
                        cameraUri = outputUri
                        cameraIntent.putExtra(android.provider.MediaStore.EXTRA_OUTPUT, outputUri)
                        cameraIntent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)

                        val contentIntent = Intent(Intent.ACTION_GET_CONTENT).apply {
                            addCategory(Intent.CATEGORY_OPENABLE)
                            type = "image/*"
                            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, fileChooserParams?.mode == FileChooserParams.MODE_OPEN_MULTIPLE)
                        }

                        val chooser = Intent(Intent.ACTION_CHOOSER).apply {
                            putExtra(Intent.EXTRA_INTENT, contentIntent)
                            putExtra(Intent.EXTRA_TITLE, "Photo choose karein")
                            putExtra(Intent.EXTRA_INITIAL_INTENTS, arrayOf(cameraIntent))
                        }
                        startActivityForResult(chooser, fileChooserReq)
                    } else {
                        val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                            addCategory(Intent.CATEGORY_OPENABLE)
                            type = "*/*"
                        }
                        startActivityForResult(intent, fileChooserReq)
                    }
                    true
                } catch (e: Exception) {
                    this@MainActivity.filePathCallback = null
                    cameraUri = null
                    Toast.makeText(this@MainActivity, "Photo select nahi ho paya", Toast.LENGTH_SHORT).show()
                    false
                }
            }
        }

        web.addJavascriptInterface(AndroidBridge(this), "AndroidApp")
        web.loadUrl("file:///android_asset/index.html")

        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), notificationReq)
        }
    }

    @Deprecated("Deprecated in Android API 33, kept for compatibility with this simple project")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != fileChooserReq) return

        val callback = filePathCallback
        filePathCallback = null

        if (resultCode != RESULT_OK) {
            cameraUri = null
            callback?.onReceiveValue(null)
            return
        }

        // Camera returns no data when EXTRA_OUTPUT is used; use the saved URI.
        if (cameraUri != null && (data == null || data.data == null)) {
            val uri = cameraUri
            cameraUri = null
            callback?.onReceiveValue(if (uri != null) arrayOf(uri) else null)
            return
        }

        cameraUri = null
        val results = WebChromeClient.FileChooserParams.parseResult(resultCode, data)
        callback?.onReceiveValue(results)
    }

    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    class AndroidBridge(private val context: Context) {
        @JavascriptInterface fun toast(message: String) = Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
        @JavascriptInterface fun scheduleReminder(id: String, customer: String, garment: String, triggerMillis: Long) {
            ReminderReceiver.schedule(context, id, customer, garment, triggerMillis)
        }
        @JavascriptInterface fun cancelReminder(id: String) = ReminderReceiver.cancel(context, id)
        @JavascriptInterface fun openNotificationSettings() {
            val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
            }
            context.startActivity(intent)
        }
    }
}
