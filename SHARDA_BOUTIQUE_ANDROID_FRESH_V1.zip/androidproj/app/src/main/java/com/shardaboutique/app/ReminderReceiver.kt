package com.shardaboutique.app

import android.app.*
import android.content.*
import android.os.Build

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val channelId = "delivery_reminders"
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(channelId, "Delivery reminders", NotificationManager.IMPORTANCE_HIGH))
        }
        val customer = intent.getStringExtra("customer") ?: "Customer"
        val garment = intent.getStringExtra("garment") ?: "Order"
        val n = Notification.Builder(context, channelId)
            .setSmallIcon(com.shardaboutique.app.R.drawable.icon_192)
            .setContentTitle("SHARDA BOUTIQUE")
            .setContentText("Delivery reminder: $customer • $garment")
            .setAutoCancel(true)
            .setPriority(Notification.PRIORITY_HIGH)
            .build()
        nm.notify((intent.getStringExtra("id") ?: System.currentTimeMillis().toString()).hashCode(), n)
    }

    companion object {
        private const val ACTION = "com.shardaboutique.app.DELIVERY_REMINDER"
        fun schedule(context: Context, id: String, customer: String, garment: String, triggerMillis: Long) {
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val i = Intent(context, ReminderReceiver::class.java).apply {
                action = ACTION; putExtra("id", id); putExtra("customer", customer); putExtra("garment", garment)
            }
            val pi = PendingIntent.getBroadcast(context, id.hashCode(), i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerMillis, pi)
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerMillis, pi)
            }
        }
        fun cancel(context: Context, id: String) {
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val i = Intent(context, ReminderReceiver::class.java)
            val pi = PendingIntent.getBroadcast(context, id.hashCode(), i, PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE)
            if (pi != null) { am.cancel(pi); pi.cancel() }
        }
    }
}
